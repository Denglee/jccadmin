self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "admin/fonts/element-icons.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "admin/fonts/element-icons.woff"
  },
  {
    "revision": "bdc8eb7d6356a74ea38ed2819e2a2f58",
    "url": "admin/img/icon_goTop.png"
  },
  {
    "revision": "28d900fae07d2f2529445f26ca3ead75",
    "url": "admin/img/icon_goTop2.png"
  },
  {
    "revision": "4122d2a958864a17f6b1",
    "url": "admin/js/Layout.1598968793031.js"
  },
  {
    "revision": "d7d5dc5ca3b64653bc3f",
    "url": "admin/js/app.1598968793031.js"
  },
  {
    "revision": "32c44c2d548530f48578",
    "url": "admin/js/bankDetails.1598968793031.js"
  },
  {
    "revision": "db42799e0818b22d7a37",
    "url": "admin/js/bankList.1598968793031.js"
  },
  {
    "revision": "59fe821912172bf82335",
    "url": "admin/js/chunk-vendors.1598968793031.js"
  },
  {
    "revision": "d85ec3486c40cc6ccd3b",
    "url": "admin/js/loanList.1598968793031.js"
  },
  {
    "revision": "341e30fba9bcb24ad23a",
    "url": "admin/js/loanList~matchIndex.1598968793031.js"
  },
  {
    "revision": "417468fc559a8ed8e174",
    "url": "admin/js/matchIndex.1598968793031.js"
  },
  {
    "revision": "bf114868b8e6862c02f1d5c450a07abd",
    "url": "index.html"
  },
  {
    "revision": "ac7696a8741f147ee94ca4087007049a",
    "url": "logo.ico"
  },
  {
    "revision": "1577c67267a9ca5a96d6b3f6004d7e1c",
    "url": "manifest.json"
  }
]);